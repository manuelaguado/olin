# mysqldatatables
Clase para procesar datatables del lado del servidor con mysql
